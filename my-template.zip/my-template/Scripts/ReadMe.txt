Perl scripts to batch convert Xmgrace files into .eps and .png files.
Modify to suit purposes.
